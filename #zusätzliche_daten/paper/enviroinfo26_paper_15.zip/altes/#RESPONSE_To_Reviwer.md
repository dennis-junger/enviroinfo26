# Response to Reviewers – Green Browsing Paper
**Status: Final Version mit eingefügten Notizen**

---

## REVIEWER 1 (Weak Accept)

### Major Issues

#### 1. Measurement Pipeline – Implementation Details
**Reviewer Concern:**
> "The measurement pipeline is only described at a very high level. Key implementation details (e.g., power‑meter model, sampling rate, calibration procedure, synchronization method between power and performance counters, analysis scripts, etc.) are missing, limiting true reproducibility."

**Response:**
Folgende Details wurden hinzugefügt oder sind verfügbar:

Measurement procedure clarified and expanded.

Added a detailed description of the GUDE Expert -Power Control 1202, including the 1 Hz measurement frequency and the fact that the device was used in its factory-calibrated state.

Clarified that only one power-metering device was used because the analysis focuses on the energy consumption of the Measurement Client.

Added an explicit description of the offline synchronization of power measurements, Windows Performance Monitor logs, and Actiona event logs using timestamps.

Clarified that timestamp alignment, baseline correction, aggregation, statistical analysis, and visualization were performed using custom Python scripts.

Local network and external communication clarified.
The description of the local network setup was expanded.

Clarified that the test website is hosted locally, while the browsers nevertheless retain Internet access and can communicate with external endpoints.
Added a more explicit explanation of the role of Pi-hole as a passive DNS monitoring component for external hostnames and background communication.


---

#### 2. Actiona Scenarios – Replication Package
**Reviewer Concern:**
> "Actiona scenarios are essential for reproducibility but were not found in the replication package."

**Response:**
✓ **Status: Erledigt** – Die Actiona-Szenarien wurden der Zenodo-Deposition hinzugefügt.
 
Baseline via https://doi.org/10.5281/zenodo.21081950
Brave  via https://doi.org/10.5281/zenodo.21139042
Chrome via https://doi.org/10.5281/zenodo.21082941
Edge via https://doi.org/10.5281/zenodo.21139455
Firefox via https://doi.org/10.5281/zenodo.21138748
Opera via https://doi.org/10.5281/zenodo.21139326

---

#### 3. Server-Power Measurements – Missing Reporting
**Reviewer Concern:**
> "Server's power consumption was measured but never reported or contextualized with client figures."

**Response:**
✓ **Status: Erledigt** – Der lokale Netzwerk-Aufbau wurde in Section 2.4 detailliert beschrieben.

**Was wir klargestellt haben:**
- **Rationale für lokaler Server:** Kontrolle über Content-Bereitstellung (kein Caching-Einfluss), reduzierte Netzwerk-Variabilität
- **Warum Internet-Verbindung?** Damit der Browser trotzdem die Background-Aktivitäten laden/aufrufen kann 
- Server power consumption was possible but we didnt meassure it troughout the experiments bc we didnt focus on our Forschungsfragen -> focus was only on the browsers not on the web server 
- ___________

---

#### 4. Scenario Realism – Synthetic vs. Real-World Browsing
**Reviewer Concern:**
> "Real-world browsing includes heterogeneous content and variable latency. How does your synthetic scenario map to typical user behavior?"

**Response:**
?? es wurde beschrieben dass mit hilfe einer Fokus gruppe ein Szenario entworfen wurde
✓ **Status: teilweise erledigt, aus platzgründen sind wir darauf nicht explizit eingegangen, räumen aber ein, dass das szenario nicht dem realword browsing entspricht 


**Was implementiert wurde:**
- 
- was tatsächlich erledigt wurde:
Representativeness of the synthetic scenario clarified. Added a sentence explicitly stating that the standardized workload should be interpreted as a representative benchmark of common browser activities rather than a complete model of everyday web usage.
---

#### 5. DNS/Telemetry Analysis – Insufficient Detail
**Reviewer Concern:**
 "DNS analysis conflates DNS request count with 'background activity' without categorizing destination domains."

**Restegorien (aus Pi-hole Logs):** 
- T
- 
wurde nicht umgesetzt, zu wenig daten -> keine bytes pro aufruf z.B, zu hoher aufwand die kategorieren zu identifizeiren und die webseiten alle zuzuordnen, über domain lassen sich teilweise nur vermutung schließen
stattdessen:
Network traffic analysis substantially expanded.
The network metric is now explicitly described as primarily representing communication with external endpoints, because the test website itself is hosted locally.
Updated network traffic values are reported: Firefox has the highest traffic (68.12 Bytes/s), while Edge has the lowest (45.51 Bytes/s).
Network traffic is now separated into sent and received data.
The revised table reports absolute values and percentages for sent/received traffic for all browsers.
DNS traffic analysis expanded.
DNS request counts are now explicitly compared with total network data volume.
The revised analysis highlights that Firefox generates the highest number of DNS requests (212.8 per run), while Edge ranks second (124.8) despite having the lowest overall network traffic.
Brave is highlighted as having comparatively high data traffic but very few DNS requests (16.8 per run).
New metric: average data volume per DNS request.
A new column for mean Bytes/request was added to the DNS results table.
This provides an additional perspective on the relationship between request frequency and data volume.
Interpretation of network and DNS metrics expanded.
The paper now explicitly explains why DNS request count and network traffic measure different aspects of browser behavior.
The discussion distinguishes the number of contacted hostnames from the total amount of exchanged data.
The interpretation of Brave's and Firefox's network behavior was added accordingly.
Limitations of DNS categorization clarified.
The revised text explicitly states that the collected data only provide the requested URL and request duration.
Individual requests therefore could not reliably be assigned to categories such as telemetry, advertising, synchronization, or content delivery.
Consequently, the interpretation of the observed network behavior is presented cautiously.
---

#### 6. Brave Paradox – Traffic vs. DNS Mismatch
**Reviewer Concern:**
> "Brave has high traffic but few DNS calls. Why? How is this connected to privacy?"

**Response:**
✓ **Status: -> wurde nicht geamcht, teil wurde rausgenommen 

-> aussage können wir nicht belegen, deshalb haben wir sie komplett rausgelöscht 

---

#### 7. Network Connectivity – Why Internet Access for Local Scenario?
**Reviewer Concern:**
> "Why is there Internet connection if the scenario runs in a local network?"

**Response:**
✓ **Status: Erledigt** – Aufbau wurde hinzugefügt.

**Klarstellung:**
- **Lokale Content-Bereitstellung:** Daten kommen vom lokalen Server ohne Caching
- **Background-Noise Messung:** Pi-hole erfasst auch DNS-Traffic außerhalb des Netzwerks (z.B. Werbung-intensive Browser), um reales Telemetrie-Verhalten abzubilden
- **Beispiel:** Ad-Traffic bei Chrome, Firefox etc. wird sichtbar gemacht
- **Status in Paper:** Section 2.4 aktualisiert ✓

---

#### 8. Statistical Significance Testing
**Reviewer Concern:**
> "Absence of statistical significance testing weakens confidence in conclusions."

**Response:**
✓ **Status: wurde nicht gemacht nur standardabweichung 
Standartabweichung wurde neu berechnet. diesmal wurde die SD zu den mittelwerten der einzelnen runs sberechnet und nicht wie vorher zu allen meswerten.

---

#### 9. Hardware/OS Scope
**Reviewer Concern:**
> "Tiny OS von Windows 11 abgrenzen"

**Response:**
✓ **Status:Erledigt** – Beschreibung von Tiny OS und die wichtigsstsen unterschiede wurden hinzugefügt.

**Was dokumentiert wurde:**
- **System-Spezifikationen:** Tiny OS (Initial-Konfiguration mit Beschreibung)
---

### Minor Issues (Reviewer 1)

| Issue | Status | Notizen |
|-------|--------|---------|
| Author list formatting | ✓ Erledigt | DJ |
| Figure text too small | ✓ Erledigt | DJ |
| Figure 2: Add looping conditions | ✓ Erledigt | DJ |
| Figure 3: "calles" → "calls"; RAM unit | ✓ Erledigt | DJ |
| Citation style (EN/DE mix) | ✓ Erledigt | DJ |
| Tiny11 reference | ✓ Erledigt | DJ – inkl. Beschreibung Initial-Konfiguration |
| Baseline vs. Idle terminology | ✓ Erledigt | DJ |
| SD calculation unclear | erledigt, Abweichungen nochmal neu berechnet  | SD berechnet über alle 20 Messläufe pro Browser: [Grund für hohe SD erklären, z.B. Temperaturfluktuationen, Background-Variabilität] |
| "Average" in Figures 4–7 undefined | ✓ Erledigt | DJ – "Mean" definiert |

---

---

## REVIEWER 2 (Weak Accept)

### Major Concern: Novelty

**Reviewer Concern:**
> "Lacking novelty – similar papers for 15+ years in EnviroInfo. How did you solve the 'scenario vs. parallel activity' problem that plagued older approaches?"

**Response:**

#### A. Novelty & Positioning vs. Ältere Arbeiten
**Response:**
Dass ähnliche Browser-Studien seit 15+ Jahren existieren, ist korrekt. Wir adressieren diese Kritik durch folgende Punkte:


- **Dick et al. (EnviroInfo 2011, 2012):** Browser-Benchmark mit standardisierten Szenarien
  - **Unterschied zu unserer Arbeit:** Damals 4 Browser (Chrome, Firefox, Opera, IE); heute Chromium-Dominanz + Brave/Edge
  - **Hardware:** Damals ältere Prozessoren/RAM; heute moderne Architektur
- **Kleinert & Arndt (2023):** Energiemessungen in Web-Anwendungen
  - **Unterschied zu unserer Arbeit:** Fokus auf serverseitige Lastverteilung, nicht auf Client-Browser-Vergleich
- **Jüngste Browser-Studien (Peters 2018, Dibenedetto 2025)

**Was sich seitdem geändert hat:**
- **Rendering-Engine-Landschaft:** Früher diverse Engines (Gecko, Trident, WebKit, Blink). Heute 4 von 5 Browsern auf Chromium/Blink → Untersuchung von gemeinsamer Engine trotz Unterschiede
- **Tracking-Landschaft:** Damals weniger Tracking-Mechaniken; heute Telemetrie, Updates, Sync allgegenwärtig
- **Blue Angel Kriterien:** Aktualisiert 2025, unsere Studie erste für neue Kriterien mit modernen Browsern
- **DNS-Monitoring:** Frühere Studien adressierten Background Services weniger – Pi-hole-Einsatz ist Novelty

**Unser Novelty-Anspruch:** 
> "Erstmalige synchrone Messung von Power + CPU + RAM + Disk + DNS für moderne Browser (2025) unter Blue Angel Kriterien; Daten offen verfügbar für Zertifizierung"

#### B. Isolation of Scenario Power from Background Activity
**Response:**
✓ **Status: Erledigt** – Methode wurde in Section 2.4 beschrieben.

**Was implementiert wurde:**
- ✓ Baseline-Messungen durchgeführt (Idle + ohne Browser)
- ✓ Szenario-Power vom Idle-Power subtrahiert
- ✓ Systemservices deaktiviert (Beschreibung via Tiny OS)

---

### Minor Issues (Reviewer 2)

#### Abbreviations & Tool Explanations

| Abbreviation | Status | Notizen |
|--------------|--------|---------|
| DNS | ✓ Erledigt | DJ – ausgeschrieben bei Einführung |
| DOM | ✓ Erledigt | DJ – ausgeschrieben |
| CPU | ✓ Erledigt | DJ – ausgeschrieben |
| RAM | ✓ Erledigt | DJ – ausgeschrieben |
| Actiona | ✓ Erledigt | DJ – kurz erklärt |
| Pi-hole | ✓ Erledigt | DJ – kurz erklärt (Tracking & AD blocking) |


---

## REVIEWER 3 (Strong Accept)

### Positive Feedback
> "This paper addresses an important topic in Green Software Engineering. Blue Angel-compliant methodology, experimental rigor, open data. Significant contribution to EnviroInfo."

**Acknowledgment:**
✓ Danke für die positive Bewertung.

---

### Minor Issues (Reviewer 3)

#### Same as Reviewer 2
✓ **Status: Alle Abkürzungen ausgeschrieben, alle Tools erklärt** (siehe Reviewer 2 Minor Issues)

---
